/* WARNING! All changes made to this file will be lost! */

#ifndef W_CUBEORANGE_AP_CONFIG_H_WAF
#define W_CUBEORANGE_AP_CONFIG_H_WAF

#define WAF_BUILD 1
#define __STDC_FORMAT_MACROS 1
#define HAVE_CMATH_ISFINITE 1
#define HAVE_CMATH_ISINF 1
#define HAVE_CMATH_ISNAN 1
#define NEED_CMATH_ISFINITE_STD_NAMESPACE 1
#define NEED_CMATH_ISINF_STD_NAMESPACE 1
#define NEED_CMATH_ISNAN_STD_NAMESPACE 1
/* #undef HAVE_ENDIAN_H */
/* #undef HAVE_BYTESWAP_H */
/* #undef HAVE_MEMRCHR */
#define PYTHONDIR "/usr/lib/python3/dist-packages"
#define PYTHONARCHDIR "/usr/lib/python3/dist-packages"
#define _GNU_SOURCE 1

#endif /* W_CUBEORANGE_AP_CONFIG_H_WAF */
